declare class Btn1Skin extends eui.Skin{
}
declare class Btn2Skin extends eui.Skin{
}
declare class BtnTab0Skin extends eui.Skin{
}
declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare class CheckBox0 extends eui.Skin{
}
declare class CheckBox1 extends eui.Skin{
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare class bar0Skin extends eui.Skin{
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class BaseBtn2Skin extends eui.Skin{
}
declare class BaseBtnSkin extends eui.Skin{
}
declare class ComBtnSkin extends eui.Skin{
}
declare class TipItemSkin extends eui.Skin{
}
declare class WindMCSkin extends eui.Skin{
}
declare class DollSkin extends eui.Skin{
}
declare class DressSkin extends eui.Skin{
}
declare class HieroglyphSkin extends eui.Skin{
}
declare class HomeSkin extends eui.Skin{
}
declare class NavigationSkin extends eui.Skin{
}
declare class LoadingUISkin extends eui.Skin{
}
declare class MaskSkin extends eui.Skin{
}
declare class QuiltItemSkin extends eui.Skin{
}
declare class QuiltSkin extends eui.Skin{
}
