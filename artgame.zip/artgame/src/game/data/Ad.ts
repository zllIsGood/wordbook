/**
 * 广告id
 * @author kei
 * @since 2020-03-10
 */
class Ad {

    public static video: string = "18uirlsxvgd19j4ky9"; //体力不足激励视频
    public static videoTip: string = "4ihfo5gui520550an6"; //关卡提示按钮激励视频

    public static loadingBanner: string = "2ec1gm57ng77j4lq6d";  //loading页面banner
    public static playBanner: string = "11qn31acsnp3j1ihmk";   //关卡结束页面banner
    public static dialogBanner: string = "1413045c8be6261gtg";   //弹窗页面banner

}
window["Ad"] = Ad;