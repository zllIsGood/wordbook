/**
 * 弹窗头部图片
 * @author chenqipeng
 * @since 2020-03-03
 */
class DialogTopImg {

    public static BACK_HOME = "dialog-back-home_png";

    public static LOGIN = "dialog-login-award_png";

    public static ENTER_STAGE = "dialog-enter-stage_png";

    public static GET_ENERGY = "dialog-get-energy_png";

    public static UNLOCK_COLOR = "dialog-unlock-color_png";


}
window["DialogTopImg"] = DialogTopImg;