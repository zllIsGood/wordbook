/**
 * 缩放实体
 * @author kei
 * @since 2019-01-27
 */
class Scale {

    public scale: number;

    public duration: number;

    public callback: Function;

}
window["Scale"] = Scale;