/**
 *  数据包id（对应协议编辑器的大id）
 * @author
 */
enum PackageID {
	/**用户*/
	User = 1,
}
