/**
 * Created by yangsong on 15-1-7.
 */
class BaseSpriteLayer extends egret.DisplayObjectContainer {
	public constructor() {
		super();
		this.touchEnabled = false;
	}
}
window["BaseSpriteLayer"]=BaseSpriteLayer